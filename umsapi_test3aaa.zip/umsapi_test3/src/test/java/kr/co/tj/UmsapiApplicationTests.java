package kr.co.tj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
